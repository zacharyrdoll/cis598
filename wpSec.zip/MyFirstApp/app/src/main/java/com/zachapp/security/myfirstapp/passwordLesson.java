package com.zachapp.security.myfirstapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class passwordLesson extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password_lesson);
    }

    public void toPassQuiz(View view){
        Intent intent = new Intent(passwordLesson.this, passwordQuiz.class);
        startActivity(intent);
    }
}
