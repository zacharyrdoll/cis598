package com.zachapp.security.myfirstapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class phishingLesson extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phishing_lesson);
    }

    public void toPhishQuiz(View view){
        Intent intent = new Intent(phishingLesson.this, phishingQuiz.class);
        startActivity(intent);
    }
}
