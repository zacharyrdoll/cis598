package com.zachapp.security.myfirstapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class passwordQuiz extends AppCompatActivity {

    int score = 0;
    int num = 1;
    TextView question;
    Button answer1;
    Button answer2;
    Button answer3;
    TextView scoreCard;
    TextView questionNum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password_quiz);
        question = (TextView) findViewById(R.id.question);
        answer1 = (Button) findViewById(R.id.choice1);
        answer2 = (Button) findViewById(R.id.choice2);
        answer3 = (Button) findViewById(R.id.choice3);
        scoreCard = (TextView) findViewById(R.id.score);
        questionNum = (TextView) findViewById(R.id.questionNum);
        loadQuestion(num);
    }

    public void onClickChoice1 (View view){
        switch(num){
            case 1:
                correct();
                loadQuestion(num);
                break;
            case 2:
                wrong();
                loadQuestion(num);
                break;
            case 3:
                correct();
                loadQuestion(num);
                break;
            case 4:
                correct();
                loadQuestion(num);
                break;
            case 5:
                wrong();
                hideQuestions();
                question.setText("Score: " + Integer.toString(score) + " / " + Integer.toString(num -1 ));
                break;
        }
    }

    public void onClickChoice2 (View view){
        switch(num){
            case 1:
                wrong();
                loadQuestion(num);
                break;
            case 2:
                correct();
                loadQuestion(num);
                break;
            case 3:
                wrong();
                loadQuestion(num);
                break;
            case 4:
                wrong();
                loadQuestion(num);
                break;
            case 5:
                wrong();
                hideQuestions();
                question.setText("Score: " + Integer.toString(score) + " / " + Integer.toString(num -1 ));
                break;
        }
    }

    public void onClickChoice3 (View view){
        switch (num){
            case 1:
                wrong();
                loadQuestion(num);
                break;
            case 2:
                wrong();
                loadQuestion(num);
                break;
            case 3:
                wrong();
                loadQuestion(num);
                break;
            case 4:
                wrong();
                loadQuestion(num);
                break;
            case 5:
                correct();
                hideQuestions();
                question.setText("Score: " + Integer.toString(score) + " / " + Integer.toString(num -1 ));
                break;
        }
    }

    public void loadQuestion (int num){
        scoreCard.setText("Score: " + Integer.toString(score) + " / " + Integer.toString(num -1 ));
        switch (num) {
            case 1:
                question.setText(getString(R.string.pq1));
                answer1.setText(getString(R.string.pq1a));
                answer2.setText(getString(R.string.pq1b));
                answer3.setText(getString(R.string.pq1c));
                break;
            case 2:
                question.setText(getString(R.string.pq2));
                answer1.setText(getString(R.string.pq2a));
                answer2.setText(getString(R.string.pq2b));
                answer3.setText(getString(R.string.pq2c));
                break;
            case 3:
                question.setText(getString(R.string.pq3));
                answer1.setText(getString(R.string.pq3a));
                answer2.setText(getString(R.string.pq3b));
                answer3.setText(getString(R.string.pq3c));
                break;
            case 4:
                question.setText(getString(R.string.pq4));
                answer1.setText(getString(R.string.pq4a));
                answer2.setText(getString(R.string.pq4b));
                answer3.setText(getString(R.string.pq4c));
                break;
            case 5:
                question.setText(getString(R.string.pq5));
                answer1.setText(getString(R.string.pq5a));
                answer2.setText(getString(R.string.pq5b));
                answer3.setText(getString(R.string.pq5c));
                break;
        }
    }
    public void correct(){
        Toast.makeText(this, "Yes! Good Job!", Toast.LENGTH_SHORT).show();
        score++;
        num++;
    }

    public void wrong(){
        Toast.makeText(this, "Wrong! Maybe next time!", Toast.LENGTH_SHORT).show();
        num++;
    }

    public void hideQuestions() {
        scoreCard.setVisibility(View.INVISIBLE);
        answer1.setVisibility(View.INVISIBLE);
        answer2.setVisibility(View.INVISIBLE);
        answer3.setVisibility(View.INVISIBLE);
        question.setTextSize(25);
    }
}
