package com.zachapp.security.myfirstapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;

public class MainActivity extends AppCompatActivity {
    public static final String EXTRA_MESSAGE = "com.example.myfirstapp.MESSAGE";
    String[] lessons = {
            "What makes a good password?",
            "Avoiding phishing attempts",
            "Safely navigating the web",
            "Basic device security",
            "Sources"
    };
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        CustomListAdapter adapt = new CustomListAdapter(this, lessons);
        listView = (ListView) findViewById(R.id.listVIewCourses);
        listView.setAdapter(adapt);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                Intent intent;
                switch (position) {
                    case 0:     intent = new Intent (MainActivity.this, passwordLesson.class);
                                break;
                    case 1:     intent = new Intent (MainActivity.this, phishingLesson.class);
                                break;
                    case 2:     intent = new Intent (MainActivity.this, webLesson.class);
                                break;
                    case 3:     intent = new Intent (MainActivity.this, deviceLesson.class);
                                break;
                    default:    intent = new Intent (MainActivity.this, lessonActivity.class);
                                break;
                }
                //String message = lessons[position];
                //intent.putExtra("lesson", message);
                startActivity(intent);
            }
        });
    }

    /*public void sendMessage(View view){
        Intent intent = new Intent(this, DisplayMessageActivity.class);
        EditText editText = (EditText) findViewById(R.id.editText);
        String message = editText.getText().toString();
        intent.putExtra(EXTRA_MESSAGE, message);
        startActivity(intent);
    }*/
}
