package com.zachapp.security.myfirstapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class deviceQuiz extends AppCompatActivity {

    int score = 0;
    int num = 1;
    TextView question;
    Button answer1;
    Button answer2;
    Button answer3;
    TextView scoreCard;
    TextView questionNum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device_quiz);
        question = (TextView) findViewById(R.id.question);
        answer1 = (Button) findViewById(R.id.choice1);
        answer2 = (Button) findViewById(R.id.choice2);
        answer3 = (Button) findViewById(R.id.choice3);
        scoreCard = (TextView) findViewById(R.id.score);
        questionNum = (TextView) findViewById(R.id.questionNum);
        loadQuestion(num);
    }

    public void onClickChoice1 (View view){
        switch(num){
            case 1:
                wrong();
                loadQuestion(num);
                break;
            case 2:
                correct();
                loadQuestion(num);
                break;
            case 3:
                wrong();
                loadQuestion(num);
                break;
            case 4:
                wrong();
                loadQuestion(num);
                break;
            case 5:
                wrong();
                hideQuestions();
                question.setText("Score: " + Integer.toString(score) + " / " + Integer.toString(num -1 ));
        }

    }

    public void onClickChoice2 (View view){
        switch(num){
            case 1:
                wrong();
                loadQuestion(num);
                break;
            case 2:
                wrong();
                loadQuestion(num);
                break;
            case 3:
                wrong();
                loadQuestion(num);
                break;
            case 4:
                correct();
                loadQuestion(num);
                break;
            case 5:
                wrong();
                hideQuestions();
                question.setText("Score: " + Integer.toString(score) + " / " + Integer.toString(num -1 ));
                break;
        }
    }

    public void onClickChoice3 (View view){
        switch (num){
            case 1:
                correct();
                loadQuestion(num);
                break;
            case 2:
                wrong();
                loadQuestion(num);
                break;
            case 3:
                correct();
                loadQuestion(num);
                break;
            case 4:
                wrong();
                loadQuestion(num);
                break;
            case 5:
                correct();
                hideQuestions();
                question.setText("Score: " + Integer.toString(score) + " / " + Integer.toString(num -1 ));
                break;
        }
    }

    public void loadQuestion (int num){
        scoreCard.setText("Score: " + Integer.toString(score) + " / " + Integer.toString(num -1 ));
        switch (num) {
            case 1:
                question.setText(getString(R.string.dq1));
                answer1.setText(getString(R.string.dq1a));
                answer2.setText(getString(R.string.dq1b));
                answer3.setText(getString(R.string.dq1c));
                break;
            case 2:
                question.setText(getString(R.string.dq2));
                answer1.setText(getString(R.string.dq2a));
                answer2.setText(getString(R.string.dq2b));
                answer3.setText(getString(R.string.dq2c));
                break;
            case 3:
                question.setText(getString(R.string.dq3));
                answer1.setText(getString(R.string.dq3a));
                answer2.setText(getString(R.string.dq3b));
                answer3.setText(getString(R.string.dq3c));
                break;
            case 4:
                question.setText(getString(R.string.dq4));
                answer1.setText(getString(R.string.dq4a));
                answer2.setText(getString(R.string.dq4b));
                answer3.setText(getString(R.string.dq4c));
                break;
            case 5:
                question.setText(getString(R.string.dq5));
                answer1.setText(getString(R.string.dq5a));
                answer2.setText(getString(R.string.dq5b));
                answer3.setText(getString(R.string.dq5c));
                break;
        }
    }

    public void correct(){
        Toast.makeText(this, "Yes! Good Job!", Toast.LENGTH_SHORT).show();
        score++;
        num++;
    }

    public void wrong(){
        Toast.makeText(this, "Wrong! Maybe next time!", Toast.LENGTH_SHORT).show();
        num++;
    }

    public void hideQuestions() {
        scoreCard.setVisibility(View.INVISIBLE);
        answer1.setVisibility(View.INVISIBLE);
        answer2.setVisibility(View.INVISIBLE);
        answer3.setVisibility(View.INVISIBLE);
        question.setTextSize(25);
    }
}
