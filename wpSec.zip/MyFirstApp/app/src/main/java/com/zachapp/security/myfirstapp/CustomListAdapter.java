package com.zachapp.security.myfirstapp;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

/**
 * Created by zacha on 3/25/2018.
 */

public class CustomListAdapter extends ArrayAdapter {
    //to reference the Activity
    private final Activity context;

    //to store the list of lessons
    private final String[] lessonArray;

    public CustomListAdapter (Activity context, String[] lessons){
        super(context, R.layout.listview_row, lessons);

        this.context=context;
        this.lessonArray = lessons;
    }

    public View getView(int position, View view, ViewGroup parent){
        LayoutInflater inflater = context.getLayoutInflater();
        View rowView = inflater.inflate(R.layout.listview_row, null, true);

        TextView lessonName = (TextView) rowView.findViewById(R.id.textViewLessonName);
        lessonName.setText(lessonArray[position]);
        return rowView;
    }
}
